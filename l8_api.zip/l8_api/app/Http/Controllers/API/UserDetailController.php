<?php
   
namespace App\Http\Controllers\API;
   
use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Validator;

class UserDetailController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::all();
    
        return $this->sendResponse($user, 'Products retrieved successfully.');
    }
    public function show($id)
    {
        if(Auth::check())
        {
            $user = User::find($id);
  
            if (is_null($user)) {
                return $this->sendError('Product not found.');
            }
       
            return $this->sendResponse($user, 'Product retrieved successfully.');
        }
        else
        return $this->sendResponse($id ,'Please Login.');
       
    }

}